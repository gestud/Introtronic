package com.example.ppa

import android.graphics.Bitmap
import java.io.Serializable

data class Componenta(var nume:String, var progres : Float,var imagine : Bitmap):Serializable {
}
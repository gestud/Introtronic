package com.example.ppa

import android.graphics.BitmapFactory
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.widget.DividerItemDecoration
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import java.util.function.Supplier

class MainActivity : AppCompatActivity() {

    lateinit var list : ArrayList<Componenta>
    lateinit var adapter : ItemAdapter


    override fun onCreate(savedInstanceState: Bundle?) {
        list= ArrayList()
        adapter= ItemAdapter(this,list)
        super.onCreate(savedInstanceState)
        LoadComponents()
        setContentView(R.layout.activity_main)

        val layoutManager = LinearLayoutManager(this)
        layoutManager.orientation=LinearLayoutManager.VERTICAL
        val recyclerView : RecyclerView = this.findViewById(R.id.list)
        val itemDec = DividerItemDecoration(this, DividerItemDecoration.VERTICAL)

        adapter= ItemAdapter(this,list)

        recyclerView.layoutManager=layoutManager
        recyclerView.addItemDecoration(itemDec)

        recyclerView.adapter=adapter


    }


    fun LoadComponents()
    {
        list.clear()
        list.add(Componenta("Rezistor",30f,BitmapFactory.decodeResource(this.resources,R.drawable.rezistor)))
        list.add(Componenta("Inductor",0f,BitmapFactory.decodeResource(this.resources,R.drawable.rezistor)))
    }
}